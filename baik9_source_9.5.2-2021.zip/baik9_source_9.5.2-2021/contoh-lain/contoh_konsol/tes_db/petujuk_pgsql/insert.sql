insert into tbl_barang (
 nomer,
 nama,
 merek,
 harga_dasar,
 tanggal_masuk,
 jumlah
) values (
 1,
 'kecap',
 'ABCD',
 500,
 '1/4/2010',
 3
);


insert into tbl_barang (
 nomer,
 nama,
 merek,
 harga_dasar,
 tanggal_masuk,
 jumlah
) values (
 2,
 'sambal',
 'DEFG',
 800,
 '2/4/2010',
 5
);


