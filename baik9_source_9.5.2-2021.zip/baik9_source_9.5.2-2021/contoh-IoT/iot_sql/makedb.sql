CREATE DATABASE smartroomdb;
