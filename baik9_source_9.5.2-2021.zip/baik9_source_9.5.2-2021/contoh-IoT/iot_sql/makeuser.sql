GRANT ALL PRIVILEGES ON smartroomdb.* TO haris@localhost IDENTIFIED BY 'haris';
