GRANT ALL PRIVILEGES ON warungdb.* TO haris@localhost IDENTIFIED BY 'haris';
