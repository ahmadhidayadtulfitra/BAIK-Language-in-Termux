insert into tbl_barang (
 nama,
 merek,
 harga_dasar,
 tanggal_masuk,
 jumlah
) values (
 "kecap",
 "ABCD",
 500,
 "1/4/2010",
 3
);


insert into tbl_barang (
 nama,
 merek,
 harga_dasar,
 tanggal_masuk,
 jumlah
) values (
 "sambal",
 "DEFG",
 800,
 "2/4/2010",
 5
);


